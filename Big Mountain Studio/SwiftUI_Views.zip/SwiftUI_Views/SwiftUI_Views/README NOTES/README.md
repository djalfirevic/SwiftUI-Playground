#  Folder Organization

You will find this project is organized the same way the book is. 

The folders on the top level represent the chapters of the book.

The folders inside the chapters represent the sections you see in the book.

# Project Changes

The git file is now included with the project so you can see the changes that were made to the latest release of the book through the Xcode project.

# Simulator
In the book, I use the iPhone 11 Simulator. So if you want to see the same resolution, I suggest using iPhone 11 or device with a similar resolution to avoid layout differences.

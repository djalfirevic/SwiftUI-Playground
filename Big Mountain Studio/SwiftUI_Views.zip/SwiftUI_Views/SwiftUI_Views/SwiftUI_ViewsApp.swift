//  Copyright © 2020 Mark Moeykens. All rights reserved. | @BigMtnStudio

import SwiftUI

@main
struct SwiftUI_ViewsApp: App {
    var body: some Scene {
        WindowGroup {
            // This is the starting point.
            // Switch out which view you want to see first.
            ScrollViewReader_Automatic()
        }
    }
}


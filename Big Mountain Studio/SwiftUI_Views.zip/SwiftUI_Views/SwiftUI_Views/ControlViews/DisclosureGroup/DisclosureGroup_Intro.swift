//  Copyright © 2020 Mark Moeykens. All rights reserved. | @BigMtnStudio

import SwiftUI

struct DisclosureGroup_Intro: View {
    @State private var disclosureExpanded = false
    @State private var disclosure2Expanded = true
    
    var body: some View {
        VStack(spacing: 20) {
            HeaderView("DisclosureGroup",
                       subtitle: "Introduction",
                       desc: "Use the DisclosureGroup when you want to expand or collapse other views.",
                       back: .orange)
            
            VStack {
                DisclosureGroup("More Info", isExpanded: $disclosureExpanded) {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.orange)
                        .opacity(0.1)
                        .overlay(Text("More Info!"))
                        .frame(height: 200)
                }
                
                DisclosureGroup("Accent Color", isExpanded: $disclosure2Expanded) {
                    Text("You can change the color of the chevron with the use of the accentColor modifier.")
                        .font(.title2)
                        .padding()
                }
                .accentColor(.orange)
                .padding()
                .background(RoundedRectangle(cornerRadius: 20)
                                .fill(Color.orange)
                                .opacity(0.1))
            }
            .padding(.horizontal)
            
            Spacer()
        }
        .font(.title)
    }
}

struct DisclosureGroup_Intro_Previews: PreviewProvider {
    static var previews: some View {
        DisclosureGroup_Intro()
    }
}
